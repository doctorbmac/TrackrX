//
//  OncologyTableViewCell.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/10/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit

class OncologyTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var Date: UITextField!
    @IBOutlet weak var Height: UITextField!
    @IBOutlet weak var Weight: UITextField!
    @IBOutlet weak var Symptoms: UITextField!
    @IBOutlet weak var DocComments: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
