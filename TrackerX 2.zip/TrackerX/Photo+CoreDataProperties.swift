//
//  Photo+CoreDataProperties.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/10/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//
//

import Foundation
import CoreData


extension Photo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photo> {
        return NSFetchRequest<Photo>(entityName: "Photo")
    }

    @NSManaged public var card_Back: NSData?
    @NSManaged public var card_Front: NSData?

}
