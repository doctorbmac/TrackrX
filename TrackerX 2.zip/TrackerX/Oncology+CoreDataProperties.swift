//
//  Oncology+CoreDataProperties.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/10/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//
//

import Foundation
import CoreData


extension Oncology {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Oncology> {
        return NSFetchRequest<Oncology>(entityName: "Oncology")
    }

    @NSManaged public var date: NSDate?
    @NSManaged public var height: Double
    @NSManaged public var weight: Double
     @NSManaged public var symptoms: String?
     @NSManaged public var doc_comments: String?

}
