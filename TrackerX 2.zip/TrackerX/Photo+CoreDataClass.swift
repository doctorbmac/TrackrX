//
//  Photo+CoreDataClass.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/10/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject {

}
