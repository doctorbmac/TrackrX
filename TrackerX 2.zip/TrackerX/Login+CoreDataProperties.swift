//
//  Login+CoreDataProperties.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/10/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//
//

import Foundation
import CoreData


extension Login {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Login> {
        return NSFetchRequest<Login>(entityName: "Login")
    }

    @NSManaged public var password: String?
    @NSManaged public var username: String?

}
