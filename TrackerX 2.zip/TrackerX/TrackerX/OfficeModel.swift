//
//  OfficeModel.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import Foundation


struct Office: Decodable {
    
    var officeName:String
    var officeLocation:String
    var longitude:Double
    var latitude:Double
    

    enum CodingKeys: String, CodingKey {
        
      
        case Name = "NAME"
        case Location = "LOCATION"
        case longitude = "LONGITUDE"
        case latitude = "LATITUDE"
      
    }
    
    init(from decoder: Decoder) throws {
        officeName = ""
        officeLocation = ""
        longitude = 0
        latitude = 0
    }
}

    class OfficeModel {
        var offices: [Office] = []
        
        init () {
            readOfficesData()
        }
        
        func getOffices() -> [Office] {
            return offices
        }
        
        func readOfficesData() {
            
            if let filename = Bundle.main.path(forResource: "DoctorsOffices", ofType: "json") {
                
                do {
                    let jsonStr = try String(contentsOfFile: filename)
                    let jsonData = jsonStr.data(using: .utf8)!
                    offices = try! JSONDecoder().decode([Office].self, from: jsonData)
                }
                catch {
                    print("The file could not be loaded")
                }
            }
        }
    }

