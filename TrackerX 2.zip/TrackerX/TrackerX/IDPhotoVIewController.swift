//
//  IDPhotoViewController.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit

class IDPhotoViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    
    @IBOutlet weak var CardBackView: UIImageView!
    
    @IBOutlet weak var CardFrontView: UIImageView!
    
    let frontImagePicker = UIImagePickerController()
    
    let backImagePicker = UIImagePickerController()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func FrontButton(_ sender: UIBarButtonItem) {
        frontImagePicker.delegate = self
        frontImagePicker.allowsEditing = false
        
        let frontActionSheet = UIAlertController(title: "Photo Source:", message: "Choose a source", preferredStyle: .actionSheet)
        frontActionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction)in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.frontImagePicker.sourceType = .camera
                
                self.present(self.frontImagePicker, animated: true, completion: nil)
            }
            else {
                print("Camera is not avaiable")
            }
        }))
        
        frontActionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            self.frontImagePicker.sourceType = .photoLibrary
            self.present(self.frontImagePicker, animated: true, completion: nil)
        }))
        
        frontActionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        if let popoverController = frontActionSheet.popoverPresentationController {
            popoverController.barButtonItem = sender
        }
        self.present(frontActionSheet, animated: true, completion: nil)
        
    }

    @IBAction func BackButton(_ sender: UIBarButtonItem) {
        backImagePicker.delegate = self
        backImagePicker.allowsEditing = false
        
        
        let backActionSheet = UIAlertController(title: "Photo Source:", message: "Choose a source", preferredStyle: .actionSheet)
        backActionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction)in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.backImagePicker.sourceType = .camera
                
                self.present(self.backImagePicker, animated: true, completion: nil)
            }
            else {
                print("Camera is not avaiable")
            }
        }))
        
        backActionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            self.backImagePicker.sourceType = .photoLibrary
            self.present(self.backImagePicker, animated: true, completion: nil)
        }))
        
        backActionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        if let popoverController = backActionSheet.popoverPresentationController {
            popoverController.barButtonItem = sender
            
        }
        self.present(backActionSheet, animated: true, completion: nil)
        
        
    }
 
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        picker.dismiss(animated: true, completion: nil)
        
        
        guard let image = info[.originalImage] as? UIImage else {return}
        CardFrontView.image = image
    }
    
    
    
    func backImagePickerController(_ picker:UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

            picker.dismiss(animated: true, completion: nil)

            guard let image = info[.originalImage] as? UIImage else {
                return
            }
           CardBackView.image = image
        }

    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("cancelled")
    }
/*func switchTabs() {
    self.tabBarController?.performSegue(withIdentifier: "MapViewController", sender: self.tabBarController)
    self.tabBarController?.performSegue(withIdentifier: "SpecialtyChoiceViewController", sender: self.tabBarController)
}*/
