//
//  LoginViewController.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit
import CoreData

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    @IBOutlet weak var UsernameLoginEmail: UITextField!
    
    @IBOutlet weak var UserLoginPassword: UITextField!
    
  
    @IBAction func UserLoginEmail(_ sender: Any) {
        
    }
    
    
    
    @IBAction func UserLoginPassword(_ sender: Any) {
    }
    
    
   /*
    @IBAction func saveLoginButton(_ sender: Any) {
        let entityDescription = NSEntityDescription.entityForName("Username", inManagedObjectContext: NSManagedObjectContext)
        
        let user = Login(entity: entityDescription!, insertIntoManagedObjectContext: NSManagedObjectContext)
        
        
        user.Username = "brad.mcnamee93@gmail.com"
        user.Password = "s1253045"
        
        do {
            try NSManagedObjectContext.save()
            Result.text = "Saved"
        }
        
        catch let error as NSError {
            Result.text = error.localizedFailureReason
        }
 
    }
*/
 }
