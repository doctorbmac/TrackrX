//
//  OfficeAnnotation.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import Foundation
import MapKit
import Contacts

class OfficeAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(_ latitude: CLLocationDegrees, _ longitude: CLLocationDegrees, title: String, subtitle: String) {
        self.coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        self.title = title
        self.subtitle = subtitle
        
    }
    
    func mapItem() -> MKMapItem {
        let destinationTitle = title! + " " + subtitle!
        let addressDict = [CNPostalAddressCityKey: destinationTitle]
        let placemark = MKPlacemark (coordinate: coordinate, addressDictionary: addressDict)
        let mapItem = MKMapItem (placemark: placemark)
        return mapItem
    }
}
