//
//  SpecialtyChoiceViewController.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit

class SpecialtyChoiceViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
  
}
    
    func switchTabs() {
self.tabBarController?.performSegue(withIdentifier: "MapViewController", sender: self.tabBarController)
        self.tabBarController?.performSegue(withIdentifier: "SpecialtyChoiceViewController", sender: self.tabBarController)
}
}
