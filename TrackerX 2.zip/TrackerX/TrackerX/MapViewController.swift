//
//  MapViewController.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/3/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

     @IBOutlet weak var MapView: MKMapView!
    
    let locationManager = CLLocationManager()
    
    let initialLocation = CLLocation (latitude: 40.280455, longitude: -74.0058114)
    
    let regionRadius: CLLocationDistance = 10000.00
    
    let OfficesModel = OfficeModel()
    
    
    var njOffices:[Office] = []
    
    var OfficeAnnotations:[OfficeAnnotation] = []
    
    var MapSize = 1000.00
    
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      // let locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        
        MapView.showsUserLocation = true
        MapView.mapType = .satellite
        MapView.delegate = self
    
        let _: MKUserLocation = MapView.userLocation
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        locationManager.startUpdatingLocation()
        centerMapOnLocation(location: initialLocation)
        addLocations()
    }
    
    func centerMapOnLocation (location: CLLocation) {
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        MapView.setRegion(coordinateRegion, animated: true)
    }
    
    
    func locationManager(_ _manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
        let newLocation = (locations[0])
        centerMapOnLocation(location: newLocation)
    }
    
    
    func annotationRefresh () {
        MapView.removeAnnotations(OfficeAnnotations)
        addLocations()
        OfficeAnnotations.removeAll()
    }
    
    func addAnnotation() {
        let annotation = MKPointAnnotation()
        let wilsonHall = CLLocation(latitude: 40.280667, longitude: -74.005445)
        annotation.coordinate = CLLocationCoordinate2D(latitude: wilsonHall.coordinate.latitude, longitude: wilsonHall.coordinate.longitude)
        annotation.title = "Wilson Hall"
        annotation.subtitle = "Monmouth University"
        MapView.addAnnotation(annotation)
    }
    
    func addLocations () {
        for Office in njOffices {
            
            let officeAnnotation = OfficeAnnotation (Office.latitude, Office.longitude, title: Office.officeName, subtitle: Office.officeLocation)
            
            officeAnnotation.title = Office.officeName
            officeAnnotation.subtitle = Office.officeLocation
            officeAnnotation.coordinate = CLLocationCoordinate2D (latitude: Office.latitude, longitude: Office.longitude)
            
            OfficeAnnotations.append(officeAnnotation)
        }
        MapView.addAnnotations(OfficeAnnotations)
        
    }
    
    
    func mapView(_mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        var annotationView = MKMarkerAnnotationView()
        guard let annotation = annotation as? OfficeAnnotation else {return nil}
        
        var identifier = " "
        _ = UIColor.blue
        
        let latitude = annotation.coordinate.latitude
        
        let officeLoc = CLLocation(latitude: annotation.coordinate.latitude, longitude: annotation.coordinate.longitude)
        
        let userLoc = CLLocation(latitude: MapView.userLocation.coordinate.latitude, longitude: MapView.userLocation.coordinate.longitude)
        
        let distanceInMeters = officeLoc.distance(from: userLoc)
        let distanceInMiles = distanceInMeters/1609.344
        
        if let dequedView = MapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView{
            annotationView = dequedView
        }
        else {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
        }
        
       return annotationView
}
    
    func mapView(_ _mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        let location = view.annotation as! OfficeAnnotation
        
        if view.rightCalloutAccessoryView == control {
            let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
            location.mapItem().openInMaps(launchOptions: launchOptions)
        }
        else if view.leftCalloutAccessoryView == control {
            
        }
    }
    @IBAction func showOffices(_ sender: Any) {
        addLocations()
    }
}
