//
//  OncologyInputViewController.swift
//  TrackerX
//
//  Created by Brad A. McNamee on 12/13/19.
//  Copyright © 2019 Monmouth University. All rights reserved.
//

import UIKit
import CoreData


// I had issues with getting the input VC to function, I've commented it out so that the build will run
/*

class InputViewController: UIViewController {

    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    @IBAction func saveOncologyAppointment (sender: AnyObject) {
        
        let entityDescription = NSEntityDescription.entityForName("Oncology", inManagedObjectContext: managedObjectContext)
        
        let OncologyInstance = Oncology(entity: entityDescription!, insertIntoManagedObjectContext: NSManagedObjectContext)
        
        OncologyInstance.date = "12-03-2019"
        OncologyInstance.height = 170
        OncologyInstance.weight = 160
        OncologyInstance.symptoms = "Shortness of breath"
        OncologyInstance.doc_comments = " Prescribed bed rest"
        
        do {
            try managedObjectContext.save()
            //result.text = "Saved"
        }
        catch let error as NSError {
           //result.text = error.localizedFailureReason
        }
    }
    }
 */
